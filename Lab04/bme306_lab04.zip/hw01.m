
get(out)
A2=out.A2
B1=out.B1
B2=out.B2
C2=out.C2
