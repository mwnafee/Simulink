% overdamped
clear
clc
k=1;
num=k;
den=[1 2 k];
sys=tf(num,den)
pzmap(sys)